import { auth } from "~/auth/server";

export const GET = auth.handler;
export const POST = auth.handler;
