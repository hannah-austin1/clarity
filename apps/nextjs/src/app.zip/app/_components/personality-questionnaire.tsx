"use client";

import { useState } from "react";

interface QuestionnaireData {
  // Turning of the Year spread (tarot-style)
  burdenCard?: string;
  burdenCardLabel?: string;
  leakCard?: string;
  leakCardLabel?: string;
  survivalSkillCard?: string;
  survivalSkillCardLabel?: string;
  shadowCostCard?: string;
  shadowCostCardLabel?: string;
  missingMedicineCard?: string;
  missingMedicineCardLabel?: string;
  helpWorksCard?: string;
  helpWorksCardLabel?: string;
  boundarySpellCard?: string;
  boundarySpellCardLabel?: string;
  northStarCard?: string;
  northStarCardLabel?: string;
  firstGateCard?: string;
  firstGateCardLabel?: string;
  emergingArchetypeCard?: string;
  emergingArchetypeCardLabel?: string;

  // Backwards-compatibility (legacy)
  yearStruggles?: string;
  yearStrugglesLabel?: string;
  yearWants?: string;
  yearWantsLabel?: string;

  // Big 5 traits
  openness: number;
  conscientiousness: number;
  extraversion: number;
  agreeableness: number;
  neuroticism: number;
  // MBTI-inspired
  intuitionVsSensing?: string;
  intuitionVsSensingLabel?: string;
  thinkingVsFeeling?: string;
  thinkingVsFeelingLabel?: string;
  // Life context
  pastExperiences?: string;
  pastExperiencesLabel?: string;
  currentChallenges?: string;
  currentChallengesLabel?: string;
  hopesAndDreams?: string;
  hopesAndDreamsLabel?: string;
  fearsAndWorries?: string;
  fearsAndWorriesLabel?: string;
  lifeArea?: string;
  lifeAreaLabel?: string;
}

interface PersonalityQuestionnaireProps {
  onComplete: (data: QuestionnaireData) => void;
  questions?: {
    id: string;
    text: string;
    options: string[];
    order: number;
    category: string | null;
  }[];
}

export function PersonalityQuestionnaire({
  onComplete,
  questions,
}: PersonalityQuestionnaireProps) {
  void questions;
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<QuestionnaireData>>({});

  const updateField = (
    field: keyof QuestionnaireData,
    value: number | string,
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const updateChoice = (
    field: keyof QuestionnaireData,
    labelField: keyof QuestionnaireData,
  ) => {
    return (value: string, label: string) => {
      setFormData((prev) => ({
        ...prev,
        [field]: value,
        [labelField]: label,
      }));
    };
  };

  const orderedQuestions = [...(questions ?? [])].sort(
    (a, b) => a.order - b.order,
  );
  const turningQuestions = orderedQuestions.filter(
    (question) => question.category === "turning_of_year",
  );
  const deckQuestions =
    turningQuestions.length > 0 ? turningQuestions : orderedQuestions;
  const totalSteps = deckQuestions.length || 1;

  const questionFieldOrder: {
    field: keyof QuestionnaireData;
    labelField: keyof QuestionnaireData;
  }[] = [
    { field: "burdenCard", labelField: "burdenCardLabel" },
    { field: "leakCard", labelField: "leakCardLabel" },
    { field: "survivalSkillCard", labelField: "survivalSkillCardLabel" },
    { field: "shadowCostCard", labelField: "shadowCostCardLabel" },
    { field: "missingMedicineCard", labelField: "missingMedicineCardLabel" },
    { field: "helpWorksCard", labelField: "helpWorksCardLabel" },
    { field: "boundarySpellCard", labelField: "boundarySpellCardLabel" },
    { field: "northStarCard", labelField: "northStarCardLabel" },
    { field: "firstGateCard", labelField: "firstGateCardLabel" },
    { field: "emergingArchetypeCard", labelField: "emergingArchetypeCardLabel" },
  ];

  const iconByPrefix: Record<string, string> = {
    burden: "🧳",
    leak: "🏺",
    survival: "🛡️",
    shadow: "🪨",
    medicine: "🧙",
    help: "🗓️",
    boundary: "🗡️",
    north: "🧭",
    first: "🚪",
    archetype: "👑",
  };

  const toOption = (raw: string) => {
    const [value, title, description] = raw.split("|");
    const prefix = value?.split("_")[0] ?? "";
    return {
      value: value ?? raw,
      title: title ?? raw,
      description: description ?? "",
      icon: iconByPrefix[prefix] ?? "✦",
    };
  };

  const defaultTraits = {
    openness: 55,
    conscientiousness: 55,
    extraversion: 50,
    agreeableness: 65,
    neuroticism: 45,
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#0b0f18] text-[#f8f4e9]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,#1c2534,transparent_55%)] opacity-90" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,rgba(216,180,118,0.2),transparent_45%)]" />
      <div className="relative z-10 container mx-auto px-4 py-12">
        <div className="mx-auto max-w-3xl">
          <div className="mb-12 text-center">
            <div className="mb-4 inline-block">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border border-amber-200/30 bg-gradient-to-br from-[#1b2433] to-[#0c1018] shadow-lg shadow-amber-300/30">
                <span className="animate-[float_6s_ease-in-out_infinite] text-4xl">
                  🜄
                </span>
              </div>
            </div>
            <h1 className="font-ritual-display mb-4 bg-gradient-to-r from-amber-200 to-amber-100 bg-clip-text text-4xl font-bold text-transparent">
              Your Ritual Begins
            </h1>
            <p className="font-ritual-text text-amber-100/70">
              Step {step} of {totalSteps}: Reflect and discover
            </p>
          </div>

          <div className="mb-12">
            <div className="mb-2 flex justify-between">
              {Array.from({ length: totalSteps }).map((_, i) => (
                <div
                  key={i}
                  className={`mx-1 h-2 flex-1 rounded-full transition-all ${
                    i + 1 <= step
                      ? "bg-gradient-to-r from-amber-200 to-amber-400"
                      : "bg-slate-700/60"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-amber-200/20 bg-black/40 p-8 shadow-2xl backdrop-blur-lg">
            {deckQuestions.length === 0 && (
              <div className="space-y-6 text-center">
                <h2 className="font-ritual-display text-2xl text-amber-100">
                  The deck is empty
                </h2>
                <p className="font-ritual-text text-amber-100/70">
                  Add questions to the database to start the ritual.
                </p>
              </div>
            )}

            {deckQuestions.length > 0 && (() => {
              const currentQuestion = deckQuestions[step - 1];
              const fieldConfig = questionFieldOrder[step - 1];
              const currentValue =
                fieldConfig ? (formData[fieldConfig.field] as string) : "";
              const parsedOptions = currentQuestion.options.map(toOption);

              return (
                <div className="space-y-8">
                  <div className="mb-8 text-center">
                    <h2 className="font-ritual-display mb-4 bg-gradient-to-r from-amber-200 to-amber-100 bg-clip-text text-3xl font-semibold text-transparent">
                      🃏 Draw Your Card
                    </h2>
                    <p className="font-ritual-text text-amber-100/70">
                      Pick the card that feels loud. We’re spotting patterns,
                      not judging.
                    </p>
                  </div>

                  <TarotChoiceQuestion
                    label={currentQuestion.text}
                    options={parsedOptions}
                    value={currentValue}
                    onChange={(value, label) => {
                      if (!fieldConfig) return;
                      updateChoice(fieldConfig.field, fieldConfig.labelField)(
                        value,
                        label,
                      );
                    }}
                  />

                  <div className="mt-8 flex gap-4">
                    {step > 1 ? (
                      <button
                        onClick={() => setStep((prev) => Math.max(1, prev - 1))}
                        className="flex-1 rounded-xl bg-slate-700/70 py-4 font-semibold transition-all hover:bg-slate-600/80"
                      >
                        ← Back
                      </button>
                    ) : (
                      <div className="flex-1" />
                    )}
                    <button
                      onClick={() => {
                        if (step < totalSteps) {
                          setStep((prev) => prev + 1);
                          return;
                        }

                        if (formData.burdenCard)
                          updateField("yearStruggles", formData.burdenCard);
                        if (formData.burdenCardLabel)
                          updateField(
                            "yearStrugglesLabel",
                            formData.burdenCardLabel,
                          );
                        if (formData.northStarCard)
                          updateField("yearWants", formData.northStarCard);
                        if (formData.northStarCardLabel)
                          updateField(
                            "yearWantsLabel",
                            formData.northStarCardLabel,
                          );

                        const completed = {
                          ...defaultTraits,
                          ...formData,
                        } as QuestionnaireData;
                        onComplete(completed);
                      }}
                      disabled={!fieldConfig || !currentValue}
                      className="flex-1 rounded-xl bg-gradient-to-r from-amber-300 to-amber-400 py-4 font-semibold text-[#15120b] shadow-lg shadow-amber-300/40 transition-all hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {step < totalSteps
                        ? "Continue →"
                        : "Complete Your Journey ✨"}
                    </button>
                  </div>
                </div>
              );
            })()}

          </div>
        </div>
      </div>
    </div>
  );
}

// Helper Components
function TarotChoiceQuestion({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: {
    value: string;
    title: string;
    description: string;
    icon: string;
  }[];
  value?: string;
  onChange: (value: string, label: string) => void;
}) {
  return (
    <div className="space-y-3">
      <label className="font-ritual-display block text-lg font-medium text-amber-100">
        {label}
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        {options.map((option) => {
          const isSelected = value === option.value;
          const labelValue = option.description
            ? `${option.title} — ${option.description}`
            : option.title;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => onChange(option.value, labelValue)}
              className={`group relative overflow-hidden rounded-[26px] border px-5 py-6 text-left transition-all duration-300 hover:-translate-y-1 hover:rotate-1 ${
                isSelected
                  ? "border-amber-200/80 bg-gradient-to-br from-amber-200/20 to-amber-200/5 shadow-lg shadow-amber-200/20"
                  : "border-amber-200/20 bg-gradient-to-br from-[#101624] to-[#080b12] hover:border-amber-200/50"
              }`}
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(216,180,118,0.18),transparent_60%)] opacity-70" />
              <div className="absolute inset-3 rounded-[20px] border border-amber-200/20" />
              <div className="absolute left-4 top-4 h-8 w-8 rounded-full border border-amber-200/30 text-center text-xs uppercase tracking-[0.2em] text-amber-200/60">
                <span className="inline-block pt-1">✦</span>
              </div>
              <div className="absolute bottom-4 right-4 h-8 w-8 rounded-full border border-amber-200/30 text-center text-xs uppercase tracking-[0.2em] text-amber-200/60">
                <span className="inline-block pt-1">✦</span>
              </div>
              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between text-xs tracking-[0.3em] text-amber-200/60 uppercase">
                  <span>Arcana</span>
                  <span>✦</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{option.icon}</span>
                  <span className="font-ritual-display text-lg text-amber-100">
                    {option.title}
                  </span>
                </div>
                {option.description ? (
                  <p className="font-ritual-text text-sm text-amber-100/70">
                    {option.description}
                  </p>
                ) : null}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
